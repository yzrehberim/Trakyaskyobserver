import { GoogleGenAI } from "@google/genai";
import { City } from "../types";

// Initialize Gemini
// Safely access process.env to avoid "Uncaught ReferenceError" in browser-native environments
const getApiKey = () => {
  try {
    return (typeof process !== 'undefined' && process.env && process.env.API_KEY) ? process.env.API_KEY : '';
  } catch (e) {
    return '';
  }
};

const API_KEY = getApiKey();

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const getSkyAnalysis = async (
  city: City, 
  date: string, 
  time: string
): Promise<string> => {
  try {
    const model = 'gemini-2.5-flash';
    const prompt = `
      Sen profesyonel bir astronomsun. Aşağıdaki konum ve zaman için Türkiye'nin Trakya bölgesi gökyüzü hakkında kısa, 
      ilgi çekici bir özet bilgi ver. Şu an hangi gezegenler görünür olabilir? Önemli bir gök olayı var mı?
      
      Konum: ${city.name} (Enlem: ${city.latitude}, Boylam: ${city.longitude})
      Tarih: ${date}
      Saat: ${time}
      
      Yanıtı Türkçe ver, maksimum 3 cümle olsun. Emoticon kullan.
    `;

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
    });

    return response.text || "Şu an gökyüzü bilgisi alınamıyor.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Yapay zeka bağlantısında bir sorun oluştu. Lütfen API anahtarını kontrol edin.";
  }
};

export const analyzeObservationNotes = async (notes: string, objects: string): Promise<string> => {
   try {
    const model = 'gemini-2.5-flash';
    const prompt = `
      Bir amatör astronom şu notları aldı:
      Gözlemlenenler: ${objects}
      Notlar: ${notes}
      
      Bu gözlem hakkında cesaretlendirici kısa bir yorum yap ve eğer bahsi geçen gök cismi hakkında ilginç bir bilgi varsa ekle.
      Yanıt Türkçe olsun.
    `;

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
    });

    return response.text || "Yorum oluşturulamadı.";
  } catch (error) {
    return "AI yorumu şu an kullanılamıyor.";
  }
}