import * as Astronomy from "astronomy-engine";
import { CelestialBody, MoonData, ConstellationState, ConstellationLineState } from '../types';
import { CONSTELLATIONS, METEOR_SHOWERS } from '../constants';

export const calculateCelestialBodies = (date: Date, lat: number, lon: number): CelestialBody[] => {
  const observer = new Astronomy.Observer(lat, lon, 0);
  const bodies: CelestialBody[] = [];
  
  // List of bodies to track
  const targets = [
    { name: 'Güneş', body: Astronomy.Body.Sun, color: '#FDB813', type: 'sun' },
    { name: 'Ay', body: Astronomy.Body.Moon, color: '#F4F6F0', type: 'moon' },
    { name: 'Merkür', body: Astronomy.Body.Mercury, color: '#A5A5A5', type: 'planet' },
    { name: 'Venüs', body: Astronomy.Body.Venus, color: '#E3BB76', type: 'planet' },
    { name: 'Mars', body: Astronomy.Body.Mars, color: '#FF4500', type: 'planet' },
    { name: 'Jüpiter', body: Astronomy.Body.Jupiter, color: '#D8CA9D', type: 'planet' },
    { name: 'Satürn', body: Astronomy.Body.Saturn, color: '#C5AB6E', type: 'planet' },
  ];

  targets.forEach(target => {
    const equ_2000 = Astronomy.Equator(target.body, date, observer, true, true);
    const hor = Astronomy.Horizon(date, observer, equ_2000.ra, equ_2000.dec, 'normal');
    
    // Only add if above horizon (or slightly below for twilight context if needed, but for map we restrict)
    // We allow drawing things slightly below horizon to show they are setting/rising
    if (hor.altitude > -5) { 
        // Get Magnitude (approximate for planets, calculated for complex bodies)
        let mag = -1; // Default bright
        if (target.type === 'planet' || target.type === 'sun' || target.type === 'moon') {
             const illum = Astronomy.Illumination(target.body, date);
             mag = illum.mag;
        }

        bodies.push({
            name: target.name,
            azimuth: hor.azimuth,
            altitude: hor.altitude,
            distance: equ_2000.dist,
            magnitude: mag,
            type: target.type as any,
            color: target.color
        });
    }
  });

  // Include some bright stars (fixed coordinates for J2000, converted to Horizon)
  const brightStars = [
    { name: 'Sirius', ra: 6.75, dec: -16.7161, color: '#A0D2EB' },
    { name: 'Betelgeuse', ra: 5.91, dec: 7.407, color: '#FF6F61' },
    { name: 'Rigel', ra: 5.24, dec: -8.201, color: '#C3E0E5' },
    { name: 'Vega', ra: 18.61, dec: 38.78, color: '#E0F7FA' },
    { name: 'Polaris', ra: 2.53, dec: 89.26, color: '#F7F7F7' },
    { name: 'Arcturus', ra: 14.26, dec: 19.18, color: '#FFD180' },
    { name: 'Antares', ra: 16.49, dec: -26.43, color: '#FF4500' },
    { name: 'Aldebaran', ra: 4.59, dec: 16.50, color: '#FFD700' }
  ];

  brightStars.forEach(star => {
     const hor = Astronomy.Horizon(date, observer, star.ra, star.dec, 'normal');
     if (hor.altitude > 0) {
         bodies.push({
             name: star.name,
             azimuth: hor.azimuth,
             altitude: hor.altitude,
             distance: 0,
             magnitude: 1, // simplified
             type: 'star',
             color: star.color
         });
     }
  });

  return bodies;
};

export const calculateConstellations = (date: Date, lat: number, lon: number): ConstellationState[] => {
    const observer = new Astronomy.Observer(lat, lon, 0);
    const visibleConstellations: ConstellationState[] = [];

    CONSTELLATIONS.forEach(constellation => {
        const calculatedLines: ConstellationLineState[] = [];
        let hasVisiblePoint = false;

        constellation.lines.forEach(line => {
            const start = Astronomy.Horizon(date, observer, line[0].ra, line[0].dec, 'normal');
            const end = Astronomy.Horizon(date, observer, line[1].ra, line[1].dec, 'normal');

            // Only add lines if at least one part is somewhat visible 
            // (Filtering strictly > 0 helps keep map clean, though partial lines at horizon are realistic)
            if (start.altitude > 0 || end.altitude > 0) {
                hasVisiblePoint = true;
                calculatedLines.push({
                    from: { azimuth: start.azimuth, altitude: start.altitude },
                    to: { azimuth: end.azimuth, altitude: end.altitude }
                });
            }
        });

        if (hasVisiblePoint && calculatedLines.length > 0) {
            visibleConstellations.push({
                name: constellation.name,
                lines: calculatedLines
            });
        }
    });

    return visibleConstellations;
};

export const getMoonPhaseData = (date: Date): MoonData => {
  const phase = Astronomy.MoonPhase(date); // 0 to 360
  const illum = Astronomy.Illumination(Astronomy.Body.Moon, date);
  
  let phaseName = '';
  let emoji = '';
  
  // Phase logic
  if (phase < 22.5) { phaseName = 'Yeni Ay'; emoji = '🌑'; }
  else if (phase < 67.5) { phaseName = 'Ay Çıkışı (Hilal)'; emoji = '🌒'; }
  else if (phase < 112.5) { phaseName = 'İlk Dördün'; emoji = '🌓'; }
  else if (phase < 157.5) { phaseName = 'Şişkin Ay'; emoji = '🌔'; }
  else if (phase < 202.5) { phaseName = 'Dolunay'; emoji = '🌕'; }
  else if (phase < 247.5) { phaseName = 'Şişkin Ay (Küçülen)'; emoji = '🌖'; }
  else if (phase < 292.5) { phaseName = 'Son Dördün'; emoji = '🌗'; }
  else if (phase < 337.5) { phaseName = 'Ay Batışı (Hilal)'; emoji = '🌘'; }
  else { phaseName = 'Yeni Ay'; emoji = '🌑'; }

  return {
    phaseName,
    illumination: illum.phase_fraction, // 0.0 to 1.0
    age: (phase / 360) * 29.53,
    emoji
  };
};

export const checkSkyEvents = (date: Date, lat: number, lon: number): string[] => {
    const events: string[] = [];
    const month = date.getMonth() + 1;
    const day = date.getDate();
    
    // Format "MM-DD"
    const currentMMDD = `${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
    
    // 1. Check Meteor Showers
    METEOR_SHOWERS.forEach(shower => {
        // Simple range check (assuming no year wrap for MVP list)
        if (currentMMDD >= shower.start && currentMMDD <= shower.end) {
            let msg = `${shower.name} Meteor Yağmuru aktif.`;
            if (currentMMDD === shower.peak) msg += " (Bu gece ZİRVE noktasında! 🔥)";
            else msg += ` (Zirve: ${shower.peak})`;
            events.push(msg);
        }
    });

    // 2. Check Major Moon Phases
    const phase = Astronomy.MoonPhase(date);
    if (Math.abs(phase - 180) < 5) events.push("Dolunay Evresi - Gökyüzü çok parlak.");
    if (phase < 5 || phase > 355) events.push("Yeni Ay - Derin uzay gözlemi için mükemmel zaman!");

    // 3. Solar Terms (Approximate)
    if (currentMMDD === '03-21') events.push("İlkbahar Ekinoksu 🌸");
    if (currentMMDD === '06-21') events.push("Yaz Gündönümü (En uzun gün) ☀️");
    if (currentMMDD === '09-23') events.push("Sonbahar Ekinoksu 🍂");
    if (currentMMDD === '12-21') events.push("Kış Gündönümü (En uzun gece) ❄️");

    // 4. Solar & Lunar Eclipses (Upcoming 45 days check)
    try {
        const nextSolar = Astronomy.SearchGlobalSolarEclipse(date);
        const daysToSolar = (nextSolar.peak.date.getTime() - date.getTime()) / (1000 * 3600 * 24);
        
        if (daysToSolar >= 0 && daysToSolar <= 45) {
            let typeTr: string = String(nextSolar.kind);
            if (typeTr === 'Total') typeTr = 'Tam';
            if (typeTr === 'Partial') typeTr = 'Parçalı';
            if (typeTr === 'Annular') typeTr = 'Halkalı';
            if (typeTr === 'Hybrid') typeTr = 'Hibrit';
            
            const eventDate = nextSolar.peak.date.toLocaleDateString('tr-TR', { day: 'numeric', month: 'long' });
            events.push(`☀️ Yaklaşan Güneş Tutulması (${typeTr}): ${eventDate}`);
        }

        const nextLunar = Astronomy.SearchLunarEclipse(date);
        const daysToLunar = (nextLunar.peak.date.getTime() - date.getTime()) / (1000 * 3600 * 24);
        
        if (daysToLunar >= 0 && daysToLunar <= 45) {
            let typeTr: string = String(nextLunar.kind);
            if (typeTr === 'Total') typeTr = 'Tam';
            if (typeTr === 'Partial') typeTr = 'Parçalı';
            if (typeTr === 'Penumbral') typeTr = 'Yarı Gölgeli';

            const eventDate = nextLunar.peak.date.toLocaleDateString('tr-TR', { day: 'numeric', month: 'long' });
            events.push(`🌑 Yaklaşan Ay Tutulması (${typeTr}): ${eventDate}`);
        }
    } catch (e) {
        console.warn("Eclipse calculation failed", e);
    }
    
    return events;
}