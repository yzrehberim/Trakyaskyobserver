import { WeatherData } from '../types';

// WMO Weather interpretation codes (simplified)
const getWeatherCondition = (code: number): string => {
  if (code === 0) return 'Açık';
  if (code === 1 || code === 2 || code === 3) return 'Parçalı Bulutlu';
  if (code === 45 || code === 48) return 'Sisli';
  if (code >= 51 && code <= 67) return 'Yağmurlu';
  if (code >= 71 && code <= 77) return 'Karlı';
  if (code >= 80 && code <= 82) return 'Sağanak Yağış';
  if (code >= 95) return 'Fırtına';
  return 'Bilinmiyor';
};

export const getRealWeather = async (lat: number, lon: number, dateStr: string, timeStr: string): Promise<WeatherData | null> => {
  try {
    // Open-Meteo accepts ISO8601 format roughly. We need to find the specific hour index.
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,is_day,cloud_cover,weather_code,wind_speed_10m&hourly=temperature_2m,cloud_cover,weather_code,wind_speed_10m&timezone=auto&forecast_days=1`;
    
    // Note: For a true historical/future specific date look up, Open-Meteo requires a different endpoint or paid plan for far history.
    // For MVP, we will use the "current" or "forecast" endpoint which covers today well.
    // If the user selects a date far in the past/future, this MVP will fallback to current live data for simplicity
    // or we could use the 'archive' endpoint for past dates, but let's stick to forecast for now.

    const response = await fetch(url);
    if (!response.ok) throw new Error('Weather API failed');
    
    const data = await response.json();
    
    // Use current data for immediate feedback
    const current = data.current;
    
    return {
      temperature: current.temperature_2m,
      cloudCover: current.cloud_cover,
      windSpeed: current.wind_speed_10m,
      conditionCode: current.weather_code,
      conditionText: getWeatherCondition(current.weather_code),
      isDay: current.is_day === 1
    };
  } catch (error) {
    console.error("Weather Service Error:", error);
    return null;
  }
};