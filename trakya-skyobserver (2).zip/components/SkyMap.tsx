import React, { useRef, useEffect, useState } from 'react';
import { CelestialBody, ConstellationState, SkyTheme } from '../types';
import { Maximize, Crosshair, Info } from 'lucide-react';
import { SKY_THEMES } from '../constants';

interface SkyMapProps {
  bodies: CelestialBody[];
  constellations?: ConstellationState[];
  width?: number;
  height?: number;
  trackedBody?: CelestialBody | null;
  onStopTracking?: () => void;
  theme?: SkyTheme;
}

const SkyMap: React.FC<SkyMapProps> = ({ 
  bodies, 
  constellations = [], 
  width = 600, 
  height = 600,
  trackedBody,
  onStopTracking,
  theme = SKY_THEMES.dark
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  // View State
  const [zoom, setZoom] = useState<number>(1);
  const [offset, setOffset] = useState<{ x: number, y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  
  // Interaction State
  const dragStartRef = useRef<{ x: number, y: number }>({ x: 0, y: 0 });
  const lastOffsetRef = useRef<{ x: number, y: number }>({ x: 0, y: 0 });
  
  // Tooltip State
  const [hoveredBody, setHoveredBody] = useState<CelestialBody | null>(null);
  const [tooltipPos, setTooltipPos] = useState<{x: number, y: number} | null>(null);

  // Reset View
  const handleReset = () => {
    setZoom(1);
    setOffset({ x: 0, y: 0 });
    lastOffsetRef.current = { x: 0, y: 0 };
    if (onStopTracking) onStopTracking();
  };

  // --- Tracking Logic ---
  useEffect(() => {
    if (!trackedBody || !canvasRef.current) return;

    const rect = canvasRef.current.getBoundingClientRect();
    const w = rect.width;
    const h = rect.height;
    
    const baseRadius = Math.min(w, h) / 2 - 20;
    const radius = baseRadius * zoom;
    
    const r = radius * ((90 - trackedBody.altitude) / 90);
    const angleRad = trackedBody.azimuth * (Math.PI / 180);
    
    // Determine required offset to center the object
    const targetOffsetX = r * Math.sin(angleRad);
    const targetOffsetY = r * Math.cos(angleRad);
    
    setOffset({ x: targetOffsetX, y: targetOffsetY });
    lastOffsetRef.current = { x: targetOffsetX, y: targetOffsetY };

  }, [trackedBody, zoom, width, height]);

  // --- Helpers ---
  // Helper: Project Azimuth/Altitude to Canvas X/Y (relative to center)
  // We need this available for both render and hit detection
  const getProjectedPosition = (az: number, alt: number, w: number, h: number, currentZoom: number, currentOffset: {x: number, y: number}) => {
      const cx = (w / 2) + currentOffset.x;
      const cy = (h / 2) + currentOffset.y;
      const baseRadius = Math.min(w, h) / 2 - 20;
      const radius = baseRadius * currentZoom;

      const r = radius * ((90 - alt) / 90);
      const angleRad = az * (Math.PI / 180);
      const x = cx - r * Math.sin(angleRad);
      const y = cy - r * Math.cos(angleRad);
      return { x, y, radius }; // Return radius for sizing logic
  };

  // --- Event Handlers ---

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    // Zoom factor
    const scaleFactor = 1.1;
    const direction = e.deltaY > 0 ? 1 / scaleFactor : scaleFactor;
    
    // Calculate new zoom level
    const newZoom = Math.min(Math.max(zoom * direction, 1), 15); // Min 1x, Max 15x

    if (newZoom === zoom) return;

    // If tracking, just update zoom, the useEffect will handle the centering offset
    if (trackedBody) {
        setZoom(newZoom);
        return;
    }

    // Standard Zoom towards pointer logic (if not tracking)
    const cw = rect.width;
    const ch = rect.height;
    
    const currentCenterX = cw / 2 + offset.x;
    const currentCenterY = ch / 2 + offset.y;
    
    const vectorX = mouseX - currentCenterX;
    const vectorY = mouseY - currentCenterY;
    
    const newVectorX = vectorX * (newZoom / zoom);
    const newVectorY = vectorY * (newZoom / zoom);
    
    const newOffsetX = offset.x + (vectorX - newVectorX);
    const newOffsetY = offset.y + (vectorY - newVectorY);

    setZoom(newZoom);
    setOffset({ x: newOffsetX, y: newOffsetY });
    lastOffsetRef.current = { x: newOffsetX, y: newOffsetY };
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (trackedBody && onStopTracking) onStopTracking(); // Break lock on manual interaction
    setIsDragging(true);
    dragStartRef.current = { x: e.clientX, y: e.clientY };
    lastOffsetRef.current = { ...offset };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();

    // 1. Dragging Logic
    if (isDragging) {
      const dx = e.clientX - dragStartRef.current.x;
      const dy = e.clientY - dragStartRef.current.y;
      
      setOffset({
        x: lastOffsetRef.current.x + dx,
        y: lastOffsetRef.current.y + dy
      });
      return;
    }

    // 2. Hover/Hit Detection Logic
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    
    let found: CelestialBody | null = null;
    
    // We need to match the projection logic exactly
    const w = rect.width;
    const h = rect.height;

    for (const body of bodies) {
        const { x, y } = getProjectedPosition(body.azimuth, body.altitude, w, h, zoom, offset);
        
        // Calculate hit threshold based on body type
        let hitRadius = 5;
        if (body.type === 'sun' || body.type === 'moon') hitRadius = 20;
        else if (body.type === 'planet') hitRadius = 10;
        
        // Scale hit radius with zoom slightly to make it easier to click when zoomed out
        hitRadius = Math.max(hitRadius, 10); 

        const dist = Math.sqrt(Math.pow(mouseX - x, 2) + Math.pow(mouseY - y, 2));
        
        if (dist <= hitRadius) {
            found = body;
            break; // Found top-most
        }
    }

    setHoveredBody(found);
    if (found) {
        setTooltipPos({ x: mouseX, y: mouseY });
    } else {
        setTooltipPos(null);
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleMouseLeave = () => {
    setIsDragging(false);
    setHoveredBody(null);
    setTooltipPos(null);
  };

  // Touch Support
  const handleTouchStart = (e: React.TouchEvent) => {
    if (trackedBody && onStopTracking) onStopTracking();
    if (e.touches.length === 1) {
        setIsDragging(true);
        dragStartRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
        lastOffsetRef.current = { ...offset };
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
      if (!isDragging || e.touches.length !== 1) return;
      const dx = e.touches[0].clientX - dragStartRef.current.x;
      const dy = e.touches[0].clientY - dragStartRef.current.y;
      setOffset({
        x: lastOffsetRef.current.x + dx,
        y: lastOffsetRef.current.y + dy
      });
  };

  // --- Rendering ---

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Handle High DPI
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    // Only resize if necessary to avoid flicker
    if (canvas.width !== rect.width * dpr || canvas.height !== rect.height * dpr) {
        canvas.width = rect.width * dpr;
        canvas.height = rect.height * dpr;
    }
    
    // Reset transform before drawing
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const w = rect.width;
    const h = rect.height;
    
    // Dynamic Center based on Zoom/Pan
    const cx = (w / 2) + offset.x;
    const cy = (h / 2) + offset.y;
    const baseRadius = Math.min(w, h) / 2 - 20;
    const radius = baseRadius * zoom;

    // Clear background with theme color
    ctx.fillStyle = theme.background;
    ctx.fillRect(0, 0, w, h);
    
    // Save context for clipping
    ctx.save();
    
    // -- Draw Content --

    // Horizon Background (The sky circle)
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    ctx.fillStyle = theme.horizonFill;
    ctx.fill();
    ctx.strokeStyle = theme.horizonStroke;
    ctx.lineWidth = 1;
    ctx.stroke();

    // Altitude Rings (30, 60 degrees)
    ctx.strokeStyle = theme.gridStroke;
    ctx.beginPath();
    [30, 60].forEach(alt => {
      const r = radius * ((90 - alt) / 90);
      ctx.moveTo(cx + r, cy);
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
    });
    ctx.stroke();

    // Cardinal Points (N, S, E, W)
    ctx.fillStyle = theme.cardinalText;
    ctx.font = '12px Inter';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    
    const cardinals = [
      { label: 'K', az: 0 },
      { label: 'D', az: 90 },
      { label: 'G', az: 180 },
      { label: 'B', az: 270 }
    ];

    cardinals.forEach(card => {
      const angleRad = (card.az) * (Math.PI / 180);
      const rText = radius + 15;
      const x = cx - rText * Math.sin(angleRad);
      const y = cy - rText * Math.cos(angleRad);
      ctx.fillText(card.label, x, y);
    });

    // --- Draw Constellation Lines ---
    ctx.strokeStyle = theme.constellationStroke;
    ctx.lineWidth = 1.5 * Math.sqrt(zoom); // Thicker lines when zoomed in
    ctx.setLineDash([]);

    constellations.forEach(constellation => {
        let cxSum = 0;
        let cySum = 0;
        let pCount = 0;

        constellation.lines.forEach(line => {
            const p1 = getProjectedPosition(line.from.azimuth, line.from.altitude, w, h, zoom, offset);
            const p2 = getProjectedPosition(line.to.azimuth, line.to.altitude, w, h, zoom, offset);

            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();

            cxSum += p1.x + p2.x;
            cySum += p1.y + p2.y;
            pCount += 2;
        });

        // Draw Constellation Label
        if (pCount > 0) {
            const nameX = cxSum / pCount;
            const nameY = cySum / pCount;
            ctx.fillStyle = theme.constellationText;
            ctx.font = `${10 * Math.sqrt(zoom)}px Inter`;
            ctx.textAlign = 'center';
            ctx.fillText(constellation.name.split(' ')[0], nameX, nameY);
        }
    });

    // --- Draw Celestial Bodies ---
    bodies.forEach(body => {
      const { x, y } = getProjectedPosition(body.azimuth, body.altitude, w, h, zoom, offset);

      // Check boundaries optimization
      if (x < -50 || y < -50 || x > w + 50 || y > h + 50) return;

      ctx.beginPath();
      
      let baseSize = 2;
      let glow = 0;

      if (body.type === 'sun') { baseSize = 10; glow = 20; }
      else if (body.type === 'moon') { baseSize = 8; glow = 10; }
      else if (body.type === 'planet') { baseSize = 4; glow = 5; }
      else { baseSize = 2; glow = 2; } // Stars

      const size = baseSize * Math.pow(zoom, 0.4);

      // Color logic adjustments for themes
      let drawColor = body.color;
      // If we are in a light theme and the star is white/very light, invert or use text color
      if (theme.id !== 'dark' && body.type === 'star') {
         if (['#F7F7F7', '#E0F7FA', '#ffffff', '#F4F6F0'].includes(body.color)) {
             drawColor = theme.textDefault;
         }
      }

      // Glow (reduce glow in light mode for stars as it looks muddy)
      if (glow > 0) {
        // Only glow if dark theme or if it's Sun/Moon
        if (theme.id === 'dark' || body.type === 'sun') {
             ctx.shadowBlur = glow * zoom;
             ctx.shadowColor = drawColor;
        }
      }

      ctx.arc(x, y, size, 0, Math.PI * 2);
      ctx.fillStyle = drawColor;
      ctx.fill();
      
      // Reset Shadow
      ctx.shadowBlur = 0;

      // Label
      const isHovered = hoveredBody?.name === body.name;
      
      if (body.type !== 'star' || ['Sirius', 'Polaris', 'Vega', 'Betelgeuse'].includes(body.name) || zoom > 2 || trackedBody?.name === body.name || isHovered) {
        ctx.fillStyle = (trackedBody?.name === body.name || isHovered) ? theme.highlight : theme.textDefault;
        ctx.font = (trackedBody?.name === body.name || isHovered) ? `bold ${12 * Math.pow(zoom, 0.3)}px Inter` : `${10 * Math.pow(zoom, 0.3)}px Inter`;
        ctx.textAlign = 'left';
        ctx.fillText(body.name, x + size + 4, y);
      }
      
      // Target reticle if tracked
      if (trackedBody?.name === body.name) {
          ctx.strokeStyle = theme.highlight;
          ctx.lineWidth = 1;
          ctx.beginPath();
          const reticleSize = size + 8;
          ctx.arc(x, y, reticleSize, 0, Math.PI * 2);
          ctx.stroke();
          
          // Crosshairs
          ctx.beginPath();
          ctx.moveTo(x - reticleSize - 5, y);
          ctx.lineTo(x - reticleSize, y);
          ctx.moveTo(x + reticleSize, y);
          ctx.lineTo(x + reticleSize + 5, y);
          ctx.moveTo(x, y - reticleSize - 5);
          ctx.lineTo(x, y - reticleSize);
          ctx.moveTo(x, y + reticleSize);
          ctx.lineTo(x, y + reticleSize + 5);
          ctx.stroke();
      }

      // Highlight if hovered
      if (isHovered && trackedBody?.name !== body.name) {
         ctx.strokeStyle = theme.textDefault;
         ctx.lineWidth = 1;
         ctx.beginPath();
         ctx.arc(x, y, size + 4, 0, Math.PI * 2);
         ctx.stroke();
      }
    });

    // Center Cross (Zenith/Center of view)
    ctx.strokeStyle = theme.crosshair;
    ctx.setLineDash([]);
    ctx.beginPath();
    const crossSize = 10 * Math.sqrt(zoom);
    ctx.moveTo(w/2 - crossSize, h/2);
    ctx.lineTo(w/2 + crossSize, h/2);
    ctx.moveTo(w/2, h/2 - crossSize);
    ctx.lineTo(w/2, h/2 + crossSize);
    ctx.stroke();
    
    ctx.restore();

  }, [bodies, constellations, width, height, zoom, offset, trackedBody, hoveredBody, theme]);

  return (
    <div className="relative w-full aspect-square max-w-[500px] mx-auto group">
      <canvas 
        ref={canvasRef} 
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseLeave}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleMouseLeave}
        className={`w-full h-full rounded-full border-4 shadow-[0_0_30px_rgba(45,166,178,0.1)] touch-none ${isDragging ? 'cursor-grabbing' : 'cursor-grab'}`}
        style={{ 
            borderColor: theme.id === 'dark' ? '#15192B' : theme.horizonStroke,
            backgroundColor: theme.background 
        }}
      />
      
      {/* Tooltip */}
      {hoveredBody && tooltipPos && (
        <div 
            className="absolute z-50 p-3 rounded-lg shadow-xl pointer-events-none transform -translate-y-full -translate-x-1/2 mb-2 animate-fadeIn"
            style={{ 
                left: tooltipPos.x, 
                top: tooltipPos.y,
                backgroundColor: theme.id === 'dark' ? 'rgba(11, 13, 23, 0.9)' : theme.background,
                border: `1px solid ${theme.horizonStroke}`,
                color: theme.textDefault
            }}
        >
            <div className="flex items-center gap-2 mb-1">
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: hoveredBody.color }}></span>
                <span className="font-bold text-sm">{hoveredBody.name}</span>
            </div>
            <div className="text-[10px] space-y-0.5 opacity-80">
                <div className="flex justify-between gap-4"><span>Tip:</span> <span className="capitalize">{hoveredBody.type}</span></div>
                <div className="flex justify-between gap-4"><span>Yükseklik (Alt):</span> <span>{hoveredBody.altitude.toFixed(1)}°</span></div>
                <div className="flex justify-between gap-4"><span>Yön (Az):</span> <span>{hoveredBody.azimuth.toFixed(1)}°</span></div>
                {hoveredBody.magnitude > -99 && <div className="flex justify-between gap-4"><span>Parlaklık (Mag):</span> <span>{hoveredBody.magnitude.toFixed(2)}</span></div>}
                {hoveredBody.distance > 0 && <div className="flex justify-between gap-4"><span>Uzaklık:</span> <span>{hoveredBody.distance.toFixed(3)} AU</span></div>}
            </div>
        </div>
      )}

      {/* HUD Info */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2 pointer-events-none transition-opacity duration-300 opacity-50 group-hover:opacity-100">
        <div className="text-[10px] px-2 py-1 rounded backdrop-blur-sm border" style={{ backgroundColor: theme.background, borderColor: theme.horizonStroke, color: theme.textDefault }}>
           Zoom: {zoom.toFixed(1)}x
        </div>
      </div>
      
      {/* Tracking Indicator */}
      {trackedBody && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 pointer-events-none">
              <div className="flex items-center gap-2 px-3 py-1 rounded-full backdrop-blur-md animate-pulse border" style={{ backgroundColor: theme.background, borderColor: theme.highlight, color: theme.highlight }}>
                  <Crosshair className="w-3 h-3" />
                  <span className="text-[10px] font-bold uppercase tracking-wider">Takip: {trackedBody.name}</span>
              </div>
          </div>
      )}
      
      {/* Controls Overlay */}
      <div className="absolute top-4 right-4 flex flex-col gap-2">
         {zoom > 1 && (
             <button 
                onClick={handleReset}
                className="p-2 rounded-full transition-all shadow-lg border"
                style={{ backgroundColor: theme.background, borderColor: theme.horizonStroke, color: theme.highlight }}
                title="Görünümü Sıfırla"
             >
                <Maximize className="w-4 h-4" />
             </button>
         )}
      </div>

      <div className="absolute bottom-2 left-1/2 -translate-x-1/2 text-[10px] px-2 py-1 rounded whitespace-nowrap pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity" style={{ backgroundColor: theme.background, color: theme.textDefault }}>
        {trackedBody ? 'Kaydırarak takibi bırak' : 'Tekerlek ile Yakınlaş • Sürükleyerek Kaydır • Detay için Üzerine Gel'}
      </div>
    </div>
  );
};

export default SkyMap;